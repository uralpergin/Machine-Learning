import numpy as np
import matplotlib.pyplot as plt

def UnivariateGaussianPDF(x, mean, std):
    return (1/(np.sqrt(2*np.pi)*std))*np.exp(-(1/2)*(((x-mean)/std)**2))


def UnivariateGMM(x, means, stds, factors):
    value = 0.0
    for model_index in range(len(means)):
        value += factors[model_index]*UnivariateGaussianPDF(x, means[model_index], stds[model_index])
    return value

xs = np.linspace(-8,8, 1000)

ys = np.apply_along_axis(UnivariateGMM, 0, xs, means=[-1.0, 3.0], stds=[np.sqrt(2), np.sqrt(1.0)], factors=[0.5, 0.5])
plt.plot(xs, ys)
plt.show()