import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator
import numpy as np

X = np.arange(-5, 5, 2)
Y = np.arange(10, 15, 2)
print(X)
print(Y)
X, Y = np.meshgrid(X, Y)


mean = np.array([0, 0])
cov = np.array([[2, 0],
                [0, 2]])
cov_inverse = np.linalg.inv(cov)
determinant = np.linalg.det(cov)

def MultivariateGaussianPDF(x, mean, cov, cov_inverse, det):
    d = len(x)
    m = np.dot(np.matmul(x-mean, cov_inverse), (x-mean))
    return (1/(np.sqrt((2*np.pi)**d)*det))*np.exp(-(1/2)*m)

# adapted from https://matplotlib.org/stable/gallery/mplot3d/surface3d.html#sphx-glr-gallery-mplot3d-surface3d-py
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})

X = np.linspace(-4, 4, 100)
Y = np.linspace(-4, 4, 100)

X, Y = np.meshgrid(X, Y)
Z = np.zeros(X.shape)

for i in range(len(X[0])):
    for j in range(len(X)):
        Z[j][i] = MultivariateGaussianPDF(np.array([X[j][i], Y[j][i]]),mean, cov, cov_inverse, determinant)


# Plot the surface.
print(X.shape, Y.shape, Z.shape)
surf = ax.plot_surface(X, Y, Z, cmap=cm.viridis,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()