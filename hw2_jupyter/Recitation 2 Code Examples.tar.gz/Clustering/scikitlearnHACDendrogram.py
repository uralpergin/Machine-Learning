import numpy as np
import math
import random
import pickle
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram
import sklearn.datasets

def plot_dendrogram(model, **kwargs):
    # Create linkage matrix and then plot the dendrogram

    # create the counts of samples under each node
    counts = np.zeros(model.children_.shape[0])
    n_samples = len(model.labels_)
    for i, merge in enumerate(model.children_):
        current_count = 0
        for child_idx in merge:
            if child_idx < n_samples:
                current_count += 1  # leaf node
            else:
                current_count += counts[child_idx - n_samples]
        counts[i] = current_count

    linkage_matrix = np.column_stack(
        [model.children_, model.distances_, counts]
    ).astype(float)

    # Plot the corresponding dendrogram
    dendrogram(linkage_matrix, **kwargs)




dataset, label = sklearn.datasets.load_wine(return_X_y=True)
max_value = np.max(np.abs(dataset), axis=0)
dataset /= max_value
print(dataset.shape)

distance_metric = "cosine"
linkage_creterion = "complete"

hac = AgglomerativeClustering(distance_threshold=0, n_clusters=None, affinity=distance_metric, linkage=linkage_creterion)
hac.fit(dataset)
print("Completed...")

plot_dendrogram(hac, truncate_mode="level", p=10)
plt.show()