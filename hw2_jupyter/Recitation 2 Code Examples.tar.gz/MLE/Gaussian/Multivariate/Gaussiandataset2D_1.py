import numpy as np
import pickle
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator


dataset = pickle.load(open("../../data/dataset2d_1.data", "rb"))

estimated_mean = np.mean(dataset, axis=0)
estimated_covariance = np.cov(dataset,rowvar=False)

estimated_cov_inverse = np.linalg.inv(estimated_covariance)
estimated_determinant = np.linalg.det(estimated_covariance)
print("Mean : ", estimated_mean)
print("Cov : ", estimated_covariance)


def MultivariateGaussianPDF(x, mean, cov, cov_inverse, det):
    d = len(x)
    m = np.dot(np.matmul(x-mean, cov_inverse), (x-mean))
    return (1/(np.sqrt((2*np.pi)**d)*det))*np.exp(-(1/2)*m)

# adapted from https://matplotlib.org/stable/gallery/mplot3d/surface3d.html#sphx-glr-gallery-mplot3d-surface3d-py
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
X = np.linspace(-4, 4, 100)
Y = np.linspace(-4, 4, 100)
X, Y = np.meshgrid(X, Y)
Z = np.zeros(X.shape)

for i in range(len(X[0])):
    for j in range(len(X)):
        Z[j][i] = MultivariateGaussianPDF(np.array([X[j][i], Y[j][i]]),mean=estimated_mean, cov=estimated_covariance, cov_inverse=estimated_cov_inverse, det=estimated_determinant)


# Plot the surface.
print(X.shape, Y.shape, Z.shape)
surf  = ax.plot_surface(X, Y, Z, cmap=cm.viridis,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
ax.scatter(dataset[:, 0], dataset[:, 1],  color="green", zs=-1, zdir='z' )

# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()