import numpy as np
import pickle
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator
from sklearn import mixture

dataset = pickle.load(open("../../data/dataset2d_2.data", "rb"))



mean = np.mean(dataset, axis=0)
cov = np.cov(dataset, rowvar=False)
cov_inverse = np.linalg.inv(cov)
determinant = np.linalg.det(cov)


def MultivariateGaussianPDF(x, mean, cov, cov_inverse, det):
    d = len(x)
    m = np.dot(np.matmul(x-mean, cov_inverse), (x-mean))
    return (1/(np.sqrt((2*np.pi)**d)*det))*np.exp(-(1/2)*m)



# adapted from https://matplotlib.org/stable/gallery/mplot3d/surface3d.html#sphx-glr-gallery-mplot3d-surface3d-py
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})

X = np.linspace(-6, 6, 100)
Y = np.linspace(-6, 6, 100)

X, Y = np.meshgrid(X, Y)
Z = np.zeros(X.shape)

for i in range(len(X[0])):
    for j in range(len(X)):
        Z[j][i] = MultivariateGaussianPDF(np.array([X[j][i], Y[j][i]]),mean, cov, cov_inverse, determinant)


# Plot the surface.
print(X.shape, Y.shape, Z.shape)
surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
ax.scatter(dataset[:, 0], dataset[:, 1],  color="green", zs=-1, zdir='z' )

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()
# Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()