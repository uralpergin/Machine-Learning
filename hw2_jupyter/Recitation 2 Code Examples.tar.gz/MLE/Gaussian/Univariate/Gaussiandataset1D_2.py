import numpy as np
import pickle
import matplotlib.pyplot as plt
from sklearn import mixture

def UnivariateGaussianPDF(x, mean, std):
    return (1/(np.sqrt(2*np.pi)*std))*np.exp(-(1/2)*(((x-mean)/std)**2))

dataset = pickle.load(open("../../data/dataset1d_2.data", "rb"))

estimated_mean = np.mean(dataset)
estimated_std = np.std(dataset)

xs = np.linspace(-4,4, 1000)
ys = np.apply_along_axis(UnivariateGaussianPDF, 0, xs, mean=estimated_mean, std=estimated_std)
plt.scatter(dataset, np.zeros(dataset.shape), color="green")
plt.plot(xs, ys)
plt.show()

