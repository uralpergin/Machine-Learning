import numpy as np
import pickle
import matplotlib.pyplot as plt
import sklearn.datasets
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from umap import UMAP

color_map = {0: "red", 1: "orange", 2: "green"}

dataset, label = sklearn.datasets.load_wine(return_X_y=True)

mean = np.mean(dataset, axis=0)
std = np.std(dataset, axis=0)
dataset = (dataset-mean)/std

# method = TSNE(n_components=2, perplexity=30, metric="euclidean") # cannot transform other data instances after training
# method = PCA(n_components=2) # can transform other data instances after training
method = UMAP(n_neighbors=100, n_components=2) # can transform other data instances after training

projected_data = method.fit_transform(dataset)
plt.scatter(projected_data[:, 0], projected_data[:, 1], c=[color_map[a] for a in label])
plt.show()
print(dataset.shape)