import pickle


dataset = pickle.load(open("../data/part3_dataset.data", "rb"))
