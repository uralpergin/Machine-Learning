import numpy as np
import math
import random
import pickle
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram
from sklearn.metrics import silhouette_score, silhouette_samples
import sklearn.datasets


dataset, label = sklearn.datasets.load_wine(return_X_y=True)
max_value = np.max(np.abs(dataset), axis=0)
dataset /= max_value

plt.scatter(dataset[:, 0], dataset[:, 1])
plt.show()

distance_metric = "cosine"
linkage_creterion = "average"

hac = AgglomerativeClustering(n_clusters=3, affinity=distance_metric, linkage=linkage_creterion)

predicted = hac.fit_predict(dataset)

silhouette_avg = silhouette_score(dataset, predicted)
sample_silhouette_values = silhouette_samples(dataset, predicted)
print(silhouette_avg)
print(predicted)
print(sample_silhouette_values)
print("Completed...")
