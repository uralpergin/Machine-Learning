import numpy as np
import pickle
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import sklearn.datasets

dataset, label = sklearn.datasets.load_wine(return_X_y=True)
max_value = np.max(np.abs(dataset), axis=0)
dataset /= max_value
print(list(set(label)))
print(dataset.shape)

scores = []

for i in range(2, 11):
    kmeans = KMeans(n_clusters=i,init="k-means++",n_init=20)
    kmeans.fit(dataset)
    scores.append(kmeans.inertia_)

predicted = kmeans.fit_predict(dataset)

plt.plot(range(2, 11), scores)

plt.show()
print("Completed...")
