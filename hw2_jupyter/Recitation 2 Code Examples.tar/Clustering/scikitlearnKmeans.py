import numpy as np
import pickle
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import sklearn.datasets

dataset, label = sklearn.datasets.load_wine(return_X_y=True)
max_value = np.max(np.abs(dataset), axis=0) # normalizing each feature to [0, 1] range
dataset /= max_value
print(dataset.shape)
print(list(set(label)))
scores = []

for i in range(2, 11):
    kmeans = KMeans(n_clusters=i,init="random",n_init=20)
    kmeans.fit(dataset)
    scores.append(kmeans.inertia_)

predicted = kmeans.fit_predict(dataset)

plt.plot(range(2, 11), scores)

plt.show()
print("Completed...")
