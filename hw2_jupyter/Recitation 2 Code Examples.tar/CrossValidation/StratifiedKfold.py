from sklearn.neighbors import KNeighborsClassifier
import sklearn.datasets
from sklearn.model_selection import StratifiedKFold, RepeatedStratifiedKFold
from sklearn.metrics import accuracy_score

dataset, label = sklearn.datasets.load_wine(return_X_y=True)
print(dataset.shape)

print(dataset)
kfold = RepeatedStratifiedKFold()

for train_indices, test_indices in kfold.split(dataset, label):
    current_train = dataset[train_indices]
    current_train_label = label[train_indices]

    knn = KNeighborsClassifier(n_neighbors=3, metric='minkowski', p=3)
    knn.fit(current_train, current_train_label)

    current_test = dataset[test_indices]
    current_test_labels = label[test_indices]

    predicted = knn.predict(current_test)
    accuracy = accuracy_score(current_test_labels, predicted)
    print("Accuracy %.2f" % accuracy)

print(dataset)