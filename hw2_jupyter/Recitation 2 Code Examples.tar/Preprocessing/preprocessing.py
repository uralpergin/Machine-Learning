import numpy as np
import matplotlib.pyplot as plt
import random


cluster1 = np.random.normal([0, 0], [0.1, 3], size=(200, 2))
cluster2 = np.random.normal([1, 0], [0.1, 3], size=(200, 2))

figures, ax = plt.subplots(4)
whole_data = np.concatenate([cluster1, cluster2])

ax[0].set_title("Original")
ax[0].set_xlim([-10, 10])
ax[0].set_ylim([-10, 10])
ax[0].scatter(whole_data[:, 0], whole_data[:, 1])


data_mean = np.mean(whole_data, axis=0)
data_std = np.std(whole_data, axis=0)
data_max = np.max(np.abs(whole_data), axis=0)

standardized_data = (whole_data-data_mean)/data_std
std_scaled_data = whole_data / data_std
scaled_data = whole_data / data_max

ax[1].set_title("standardized")
ax[1].set_xlim([-10, 10])
ax[1].set_ylim([-10, 10])
ax[1].scatter(standardized_data[:, 0], standardized_data[:, 1])

ax[2].set_title("std scaled")
ax[2].set_xlim([-10, 10])
ax[2].set_ylim([-10, 10])
ax[2].scatter(std_scaled_data[:, 0], std_scaled_data[:, 1])

ax[3].set_title("scaled")
ax[3].set_xlim([-10, 10])
ax[3].set_ylim([-10, 10])
ax[3].scatter(scaled_data[:, 0], scaled_data[:, 1])
plt.show()