import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator
import numpy as np

X = np.arange(-5, 5, 2)
Y = np.arange(10, 15, 2)
print(X)
print(Y)
X, Y = np.meshgrid(X, Y)
R = np.sqrt(X**2 + Y**2)
print(X.shape, Y.shape, R.shape)
print(X)
print(Y)

mean1 = np.array([0, 0])
cov1 = np.array([[1, 1],
                [0, 1]])
cov_inverse1 = np.linalg.inv(cov1)
determinant1 = np.linalg.det(cov1)

mean2 = np.array([3, 3])
cov2 = np.array([[1, 0],
                [0, 1]])
cov_inverse2 = np.linalg.inv(cov2)
determinant2 = np.linalg.det(cov2)

mean3 = np.array([-2, 1])
cov3 = np.array([[1, 0],
                [0, 1]])
cov_inverse3 = np.linalg.inv(cov3)
determinant3 = np.linalg.det(cov3)


means = [mean1, mean2, mean3]
covs = [cov1, cov2, cov3]
cov_inverses = [cov_inverse1, cov_inverse2, cov_inverse3]
determinants = [determinant1, determinant2, determinant3]
factors = [0.33, 0.33,0.33]

def MultivariateGaussianPDF(x, mean, cov, cov_inverse, det):
    d = len(x)
    m = np.dot(np.matmul(x-mean, cov_inverse), (x-mean))
    return (1/(np.sqrt((2*np.pi)**d)*det))*np.exp(-(1/2)*m)


def MultivariateGaussianMixtureModelPDF(x, means, covs, cov_inverses, dets, factors):
    value = 0
    for model_index in range(len(means)):
        value += factors[model_index]*MultivariateGaussianPDF(x, means[model_index], covs[model_index], cov_inverses[model_index], dets[model_index])

    return value

# adapted from https://matplotlib.org/stable/gallery/mplot3d/surface3d.html#sphx-glr-gallery-mplot3d-surface3d-py
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})

X = np.linspace(-6, 6, 100)
Y = np.linspace(-6, 6, 100)

X, Y = np.meshgrid(X, Y)
Z = np.zeros(X.shape)

for i in range(len(X[0])):
    for j in range(len(X)):
        Z[j][i] = MultivariateGaussianMixtureModelPDF(np.array([X[j][i], Y[j][i]]),means, covs, cov_inverses, determinants, factors)


# Plot the surface.
print(X.shape, Y.shape, Z.shape)
surf = ax.plot_surface(X, Y, Z, cmap=cm.coolwarm,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()