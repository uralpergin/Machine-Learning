import numpy as np
import matplotlib.pyplot as plt

def UnivariateGaussianPDF(x, mean, std):
    return (1/(np.sqrt(2*np.pi)*std))*np.exp(-(1/2)*(((x-mean)/std)**2))


xs = np.linspace(-4,6, 1000)

ys = np.apply_along_axis(UnivariateGaussianPDF, 0, xs, mean=1.0, std=np.sqrt(10))
plt.plot(xs, ys)
plt.show()