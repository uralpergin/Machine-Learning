import numpy as np
import pickle
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator
from sklearn import mixture


dataset = pickle.load(open("../../data/dataset2d_2.data", "rb"))


model = mixture.GaussianMixture(n_components=3, covariance_type="full")
model.fit(dataset)

print("Means : ", model.means_)
print("Covs : ", model.covariances_)
print("Factors : ", model.weights_)

mean1 = model.means_[0]
cov1 = model.covariances_[0]
cov_inverse1 = np.linalg.inv(cov1)
determinant1 = np.linalg.det(cov1)

mean2 = model.means_[1]
cov2 = model.covariances_[1]
cov_inverse2 = np.linalg.inv(cov2)
determinant2 = np.linalg.det(cov2)

mean3 = model.means_[2]
cov3 = model.covariances_[2]
cov_inverse3 = np.linalg.inv(cov3)
determinant3 = np.linalg.det(cov3)


means = [mean1, mean2, mean3]
covs = [cov1, cov2, cov3]
cov_inverses = [cov_inverse1, cov_inverse2, cov_inverse3]
determinants = [determinant1, determinant2, determinant3]
factors = model.weights_


def MultivariateGaussianPDF(x, mean, cov, cov_inverse, det):
    d = len(x)
    m = np.dot(np.matmul(x-mean, cov_inverse), (x-mean))
    return (1/(np.sqrt((2*np.pi)**d)*det))*np.exp(-(1/2)*m)


def MultivariateGaussianMixtureModelPDF(x, means, covs, cov_inverses, dets, factors):
    value = 0
    for model_index in range(len(means)):
        value += factors[model_index]*MultivariateGaussianPDF(x, means[model_index], covs[model_index], cov_inverses[model_index], dets[model_index])

    return value
# adapted from https://matplotlib.org/stable/gallery/mplot3d/surface3d.html#sphx-glr-gallery-mplot3d-surface3d-py
fig, ax = plt.subplots(subplot_kw={"projection": "3d"})
X = np.linspace(-4, 4, 100)
Y = np.linspace(-4, 4, 100)
X, Y = np.meshgrid(X, Y)
Z = np.zeros(X.shape)

for i in range(len(X[0])):
    for j in range(len(X)):
        Z[j][i] = MultivariateGaussianMixtureModelPDF(np.array([X[j][i], Y[j][i]]),means=means, covs=covs, cov_inverses=cov_inverses, dets=determinants, factors = factors)


# Plot the surface.
print(X.shape, Y.shape, Z.shape)
surf  = ax.plot_surface(X, Y, Z, cmap=cm.viridis,
                       linewidth=0, antialiased=False)

# Customize the z axis.
ax.zaxis.set_major_locator(LinearLocator(10))
ax.scatter(dataset[:, 0], dataset[:, 1],  color="green", zs=-1, zdir='z' )

# A StrMethodFormatter is used automatically
ax.zaxis.set_major_formatter('{x:.02f}')

# Add a color bar which maps values to colors.
# fig.colorbar(surf, shrink=0.5, aspect=5)

plt.show()