import numpy as np
import pickle
import matplotlib.pyplot as plt
from sklearn import mixture

def UnivariateGaussianPDF(x, mean, std):
    return (1/(np.sqrt(2*np.pi)*std))*np.exp(-(1/2)*(((x-mean)/std)**2))

dataset = pickle.load(open("../../data/dataset1d_2.data", "rb"))

def UnivariateGMM(x, means, stds, factors):
    value = 0.0
    for model_index in range(len(means)):
        value += factors[model_index]*UnivariateGaussianPDF(x, means[model_index], stds[model_index])
    return value


model = mixture.GaussianMixture(n_components=2, covariance_type="full")
model.fit(dataset.reshape(-1, 1))

print("Mean : ", model.means_)
print("Stds : ", model.covariances_)
print("Factors : ", model.weights_)

estimated_means = [model.means_[0][0], model.means_[1][0]]
estimated_stds = [np.sqrt(model.covariances_[0][0][0]), np.sqrt(model.covariances_[1][0][0])]
estimated_factors = model.weights_

xs = np.linspace(-4,4, 1000)
ys = np.apply_along_axis(UnivariateGMM, 0, xs, means=estimated_means, stds=estimated_stds, factors = estimated_factors)
plt.scatter(dataset, np.zeros(dataset.shape), color="green")
plt.plot(xs, ys)
plt.show()